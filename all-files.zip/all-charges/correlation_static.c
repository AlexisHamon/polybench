
#include <stdio.h>
#include <sys/time.h>
#include "rtclock.h"
#include <stdlib.h>
#define MAX_THREADS 256

/* Initialization temporal variables */
double t_start;

double tall_start;
/* récupération du nombre de threads, avant la section omp parallel.
 Avant la première exécution du programme, il faut renseigner la variable
 d'environnement : export OMP_NUM_THREADS=X, où X est le nombre de threads */
int _ThreadCount; 
double _time_threads[MAX_THREADS];





#include <math.h>
#define ceild(n,d)  (((n)<0) ? -((-(n))/(d)) : ((n)+(d)-1)/(d))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))
#define max(x,y)    ((x) > (y)? (x) : (y))
#define min(x,y)    ((x) < (y)? (x) : (y))

#include <omp.h>
/**
 * This version is stamped on May 10, 2016
 *
 * Contact:
 *   Louis-Noel Pouchet <pouchet.ohio-state.edu>
 *   Tomofumi Yuki <tomofumi.yuki.fr>
 *
 * Web address: http://polybench.sourceforge.net
 */
/* correlation.c: this file is part of PolyBench/C */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include <polybench.h>

/* Include benchmark-specific header. */
#include "correlation.h"


/* Array initialization. */
static
void init_array (int m,
		 int n,
		 DATA_TYPE *float_n,
		 DATA_TYPE POLYBENCH_2D(data,N,M,n,m))
{
  int i, j;

  *float_n = (DATA_TYPE)N;

  for (i = 0; i < N; i++)
    for (j = 0; j < M; j++)
      data[i][j] = (DATA_TYPE)(i*j)/M + i;

}


/* DCE code. Must scan the entire live-out data.
   Can be used also to check the correctness of the output. */
static
void print_array(int m,
		 DATA_TYPE POLYBENCH_2D(corr,M,M,m,m))

{
  int i, j;

  POLYBENCH_DUMP_START;
  POLYBENCH_DUMP_BEGIN("corr");
  for (i = 0; i < m; i++)
    for (j = 0; j < m; j++) {
      if ((i * m + j) % 20 == 0) fprintf (POLYBENCH_DUMP_TARGET, "\n");
      fprintf (POLYBENCH_DUMP_TARGET, DATA_PRINTF_MODIFIER, corr[i][j]);
    }
  POLYBENCH_DUMP_END("corr");
  POLYBENCH_DUMP_FINISH;
}


/* Main computational kernel. The whole function will be timed,
   including the call and return. */
static
void kernel_correlation(int m, int n,
			DATA_TYPE float_n,
			DATA_TYPE POLYBENCH_2D(data,N,M,n,m),
			DATA_TYPE POLYBENCH_2D(corr,M,M,m,m),
			DATA_TYPE POLYBENCH_1D(mean,M,m),
			DATA_TYPE POLYBENCH_1D(stddev,M,m))
{
  int i, j, k;

  DATA_TYPE eps = SCALAR_VAL(0.1);


  int t1, t2, t3, t4, t5, t6, t7, t8;
 int lb, ub, lbp, ubp, lb2, ub2;
 register int lbv, ubv;
corr[_PB_M-1][_PB_M-1] = SCALAR_VAL(1.0);;
lbp=0;
ubp=floord(_PB_M-2,64);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait private(lbv,ubv,t3,t4,t5,t6,t7,t8)
for (t2=lbp;t2<=ubp;t2++) {
  for (t3=ceild(t2-1,2);t3<=floord(_PB_M-1,128);t3++) {
    for (t4=64*t2;t4<=min(min(_PB_M-2,64*t2+63),128*t3+126);t4++) {
      lbv=max(128*t3,t4+1);
      ubv=min(_PB_M-1,128*t3+127);
#pragma GCC ivdep
      for (t5=lbv;t5<=ubv;t5++) {
        corr[t4][t5] = SCALAR_VAL(0.0);;
      }
    }
  }
}
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
lbp=0;
ubp=floord(_PB_M-1,64);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait private(lbv,ubv,t3,t4,t5,t6,t7,t8)
for (t2=lbp;t2<=ubp;t2++) {
  lbv=64*t2;
  ubv=min(_PB_M-2,64*t2+63);
#pragma GCC ivdep
  for (t3=lbv;t3<=ubv;t3++) {
    corr[t3][t3] = SCALAR_VAL(1.0);;
    stddev[t3] = SCALAR_VAL(0.0);;
    mean[t3] = SCALAR_VAL(0.0);;
  }
  if (t2 >= ceild(_PB_M-64,64)) {
    stddev[(_PB_M-1)] = SCALAR_VAL(0.0);;
    mean[(_PB_M-1)] = SCALAR_VAL(0.0);;
  }
}
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
if (_PB_N >= 1) {
  lbp=0;
  ubp=floord(_PB_M-1,64);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait private(lbv,ubv,t3,t4,t5,t6,t7,t8)
  for (t2=lbp;t2<=ubp;t2++) {
    for (t3=0;t3<=floord(_PB_N-1,128);t3++) {
      for (t4=128*t3;t4<=min(_PB_N-1,128*t3+127);t4++) {
        lbv=64*t2;
        ubv=min(_PB_M-1,64*t2+63);
#pragma GCC ivdep
        for (t5=lbv;t5<=ubv;t5++) {
          mean[t5] += data[t4][t5];;
        }
      }
    }
  }
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
}
lbp=0;
ubp=floord(_PB_M-1,64);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait private(lbv,ubv,t3,t4,t5,t6,t7,t8)
for (t2=lbp;t2<=ubp;t2++) {
  lbv=64*t2;
  ubv=min(_PB_M-1,64*t2+63);
#pragma GCC ivdep
  for (t3=lbv;t3<=ubv;t3++) {
    mean[t3] /= float_n;;
  }
}
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
if (_PB_N >= 1) {
  lbp=0;
  ubp=floord(_PB_M-1,64);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait private(lbv,ubv,t3,t4,t5,t6,t7,t8)
  for (t2=lbp;t2<=ubp;t2++) {
    for (t3=0;t3<=floord(_PB_N-1,128);t3++) {
      for (t4=128*t3;t4<=min(_PB_N-1,128*t3+127);t4++) {
        lbv=64*t2;
        ubv=min(_PB_M-1,64*t2+63);
#pragma GCC ivdep
        for (t5=lbv;t5<=ubv;t5++) {
          stddev[t5] += (data[t4][t5] - mean[t5]) * (data[t4][t5] - mean[t5]);;
          data[t4][t5] -= mean[t5];;
        }
      }
    }
  }
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
}
lbp=0;
ubp=floord(_PB_M-1,64);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait private(lbv,ubv,t3,t4,t5,t6,t7,t8)
for (t2=lbp;t2<=ubp;t2++) {
  lbv=64*t2;
  ubv=min(_PB_M-1,64*t2+63);
#pragma GCC ivdep
  for (t3=lbv;t3<=ubv;t3++) {
    stddev[t3] /= float_n;;
    stddev[t3] = SQRT_FUN(stddev[t3]);;
    stddev[t3] = stddev[t3] <= eps ? SCALAR_VAL(1.0) : stddev[t3];;
  }
}
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
if (_PB_M >= 1) {
  lbp=0;
  ubp=floord(_PB_N-1,64);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait private(lbv,ubv,t3,t4,t5,t6,t7,t8)
  for (t2=lbp;t2<=ubp;t2++) {
    for (t3=0;t3<=floord(_PB_M-1,128);t3++) {
      for (t4=64*t2;t4<=min(_PB_N-1,64*t2+63);t4++) {
        lbv=128*t3;
        ubv=min(_PB_M-1,128*t3+127);
#pragma GCC ivdep
        for (t5=lbv;t5<=ubv;t5++) {
          data[t4][t5] /= SQRT_FUN(float_n) * stddev[t5];;
        }
      }
    }
  }
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
}
if (_PB_N >= 1) {
  lbp=0;
  ubp=floord(_PB_M-2,64);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait private(lbv,ubv,t3,t4,t5,t6,t7,t8)
  for (t2=lbp;t2<=ubp;t2++) {
    for (t3=ceild(t2-1,2);t3<=floord(_PB_M-1,128);t3++) {
      for (t4=0;t4<=floord(_PB_N-1,8);t4++) {
        for (t5=64*t2;t5<=min(min(_PB_M-2,64*t2+63),128*t3+126);t5++) {
          for (t6=8*t4;t6<=min(_PB_N-1,8*t4+7);t6++) {
            lbv=max(128*t3,t5+1);
            ubv=min(_PB_M-1,128*t3+127);
#pragma GCC ivdep
            for (t7=lbv;t7<=ubv;t7++) {
              corr[t5][t7] += (data[t6][t5] * data[t6][t7]);;
            }
          }
        }
      }
    }
  }
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
}
lbp=0;
ubp=floord(_PB_M-2,64);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait private(lbv,ubv,t3,t4,t5,t6,t7,t8)
for (t2=lbp;t2<=ubp;t2++) {
  for (t3=ceild(t2-1,2);t3<=floord(_PB_M-1,128);t3++) {
    for (t4=64*t2;t4<=min(min(_PB_M-2,64*t2+63),128*t3+126);t4++) {
      lbv=max(128*t3,t4+1);
      ubv=min(_PB_M-1,128*t3+127);
#pragma GCC ivdep
      for (t5=lbv;t5<=ubv;t5++) {
        corr[t5][t4] = corr[t4][t5];;
      }
    }
  }
}
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}

/* Affichage des temps d'exécution */
tall_start=rtclock()-tall_start; 
for(int i=0;i<_ThreadCount;i++){
printf("%0.6lf \n", _time_threads[i]);
}
 printf("##Execution time \n");

}


int main(int argc, char** argv)
{
_ThreadCount = atoi(getenv("OMP_NUM_THREADS"));
  for (int _i=0; _i<_ThreadCount; _i++) _time_threads[_i]=0.0; /*initialisation du tableau des mesures à 0 */
  /* temps d'exécution totale */
  tall_start=rtclock();

  /* Retrieve problem size. */
  int n = N;
  int m = M;

  /* Variable declaration/allocation. */
  DATA_TYPE float_n;
  POLYBENCH_2D_ARRAY_DECL(data,DATA_TYPE,N,M,n,m);
  POLYBENCH_2D_ARRAY_DECL(corr,DATA_TYPE,M,M,m,m);
  POLYBENCH_1D_ARRAY_DECL(mean,DATA_TYPE,M,m);
  POLYBENCH_1D_ARRAY_DECL(stddev,DATA_TYPE,M,m);

  /* Initialize array(s). */
  init_array (m, n, &float_n, POLYBENCH_ARRAY(data));

  /* Start timer. */
  polybench_start_instruments;

  /* Run kernel. */
  kernel_correlation (m, n, float_n,
		      POLYBENCH_ARRAY(data),
		      POLYBENCH_ARRAY(corr),
		      POLYBENCH_ARRAY(mean),
		      POLYBENCH_ARRAY(stddev));

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print_array(m, POLYBENCH_ARRAY(corr)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(data);
  POLYBENCH_FREE_ARRAY(corr);
  POLYBENCH_FREE_ARRAY(mean);
  POLYBENCH_FREE_ARRAY(stddev);

  return 0;
}
