
#include <stdio.h>
#include <sys/time.h>
#include "rtclock.h"
#include <stdlib.h>
#define MAX_THREADS 256

/* Initialization temporal variables */
double t_start;

double tall_start;
/* récupération du nombre de threads, avant la section omp parallel.
 Avant la première exécution du programme, il faut renseigner la variable
 d'environnement : export OMP_NUM_THREADS=X, où X est le nombre de threads */
int _ThreadCount; 
double _time_threads[MAX_THREADS];





#include <math.h>
#define ceild(n,d)  (((n)<0) ? -((-(n))/(d)) : ((n)+(d)-1)/(d))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))
#define max(x,y)    ((x) > (y)? (x) : (y))
#define min(x,y)    ((x) < (y)? (x) : (y))

#include <omp.h>
/**
 * This version is stamped on May 10, 2016
 *
 * Contact:
 *   Louis-Noel Pouchet <pouchet.ohio-state.edu>
 *   Tomofumi Yuki <tomofumi.yuki.fr>
 *
 * Web address: http://polybench.sourceforge.net
 */
/* bicg.c: this file is part of PolyBench/C */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include <polybench.h>

/* Include benchmark-specific header. */
#include "bicg.h"


/* Array initialization. */
static
void init_array (int m, int n,
		 DATA_TYPE POLYBENCH_2D(A,N,M,n,m),
		 DATA_TYPE POLYBENCH_1D(r,N,n),
		 DATA_TYPE POLYBENCH_1D(p,M,m))
{
  int i, j;

  for (i = 0; i < m; i++)
    p[i] = (DATA_TYPE)(i % m) / m;
  for (i = 0; i < n; i++) {
    r[i] = (DATA_TYPE)(i % n) / n;
    for (j = 0; j < m; j++)
      A[i][j] = (DATA_TYPE) (i*(j+1) % n)/n;
  }
}


/* DCE code. Must scan the entire live-out data.
   Can be used also to check the correctness of the output. */
static
void print_array(int m, int n,
		 DATA_TYPE POLYBENCH_1D(s,M,m),
		 DATA_TYPE POLYBENCH_1D(q,N,n))

{
  int i;

  POLYBENCH_DUMP_START;
  POLYBENCH_DUMP_BEGIN("s");
  for (i = 0; i < m; i++) {
    if (i % 20 == 0) fprintf (POLYBENCH_DUMP_TARGET, "\n");
    fprintf (POLYBENCH_DUMP_TARGET, DATA_PRINTF_MODIFIER, s[i]);
  }
  POLYBENCH_DUMP_END("s");
  POLYBENCH_DUMP_BEGIN("q");
  for (i = 0; i < n; i++) {
    if (i % 20 == 0) fprintf (POLYBENCH_DUMP_TARGET, "\n");
    fprintf (POLYBENCH_DUMP_TARGET, DATA_PRINTF_MODIFIER, q[i]);
  }
  POLYBENCH_DUMP_END("q");
  POLYBENCH_DUMP_FINISH;
}


/* Main computational kernel. The whole function will be timed,
   including the call and return. */
static
void kernel_bicg(int m, int n,
		 DATA_TYPE POLYBENCH_2D(A,N,M,n,m),
		 DATA_TYPE POLYBENCH_1D(s,M,m),
		 DATA_TYPE POLYBENCH_1D(q,N,n),
		 DATA_TYPE POLYBENCH_1D(p,M,m),
		 DATA_TYPE POLYBENCH_1D(r,N,n))
{
  int i, j;

  int t1, t2, t3, t4, t5;
 int lb, ub, lbp, ubp, lb2, ub2;
 register int lbv, ubv;
lbp=0;
ubp=floord(_PB_N-1,96);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait private(lbv,ubv,t3,t4,t5)
for (t2=lbp;t2<=ubp;t2++) {
  lbv=96*t2;
  ubv=min(_PB_N-1,96*t2+95);
#pragma GCC ivdep
  for (t3=lbv;t3<=ubv;t3++) {
    q[t3] = SCALAR_VAL(0.0);;
  }
}
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
if (_PB_M >= 1) {
  lbp=0;
  ubp=floord(_PB_N-1,96);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait private(lbv,ubv,t3,t4,t5)
  for (t2=lbp;t2<=ubp;t2++) {
    for (t3=0;t3<=floord(_PB_M-1,64);t3++) {
      for (t4=96*t2;t4<=min(_PB_N-1,96*t2+95);t4++) {
        for (t5=64*t3;t5<=min(_PB_M-1,64*t3+63);t5++) {
          q[t4] = q[t4] + A[t4][t5] * p[t5];;
        }
      }
    }
  }
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
}
lbp=0;
ubp=floord(_PB_M-1,96);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait private(lbv,ubv,t3,t4,t5)
for (t2=lbp;t2<=ubp;t2++) {
  lbv=96*t2;
  ubv=min(_PB_M-1,96*t2+95);
#pragma GCC ivdep
  for (t3=lbv;t3<=ubv;t3++) {
    s[t3] = 0;;
  }
}
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
if (_PB_N >= 1) {
  lbp=0;
  ubp=floord(_PB_M-1,96);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait private(lbv,ubv,t3,t4,t5)
  for (t2=lbp;t2<=ubp;t2++) {
    for (t3=0;t3<=floord(_PB_N-1,64);t3++) {
      for (t4=64*t3;t4<=min(_PB_N-1,64*t3+63);t4++) {
        lbv=96*t2;
        ubv=min(_PB_M-1,96*t2+95);
#pragma GCC ivdep
        for (t5=lbv;t5<=ubv;t5++) {
          s[t5] = s[t5] + r[t4] * A[t4][t5];;
        }
      }
    }
  }
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
}

/* Affichage des temps d'exécution */
tall_start=rtclock()-tall_start; 
for(int i=0;i<_ThreadCount;i++){
printf("%0.6lf \n", _time_threads[i]);
}
 printf("##Execution time \n");

}


int main(int argc, char** argv)
{
_ThreadCount = atoi(getenv("OMP_NUM_THREADS"));
  for (int _i=0; _i<_ThreadCount; _i++) _time_threads[_i]=0.0; /*initialisation du tableau des mesures à 0 */
  /* temps d'exécution totale */
  tall_start=rtclock();

  /* Retrieve problem size. */
  int n = N;
  int m = M;

  /* Variable declaration/allocation. */
  POLYBENCH_2D_ARRAY_DECL(A, DATA_TYPE, N, M, n, m);
  POLYBENCH_1D_ARRAY_DECL(s, DATA_TYPE, M, m);
  POLYBENCH_1D_ARRAY_DECL(q, DATA_TYPE, N, n);
  POLYBENCH_1D_ARRAY_DECL(p, DATA_TYPE, M, m);
  POLYBENCH_1D_ARRAY_DECL(r, DATA_TYPE, N, n);

  /* Initialize array(s). */
  init_array (m, n,
	      POLYBENCH_ARRAY(A),
	      POLYBENCH_ARRAY(r),
	      POLYBENCH_ARRAY(p));

  /* Start timer. */
  polybench_start_instruments;

  /* Run kernel. */
  kernel_bicg (m, n,
	       POLYBENCH_ARRAY(A),
	       POLYBENCH_ARRAY(s),
	       POLYBENCH_ARRAY(q),
	       POLYBENCH_ARRAY(p),
	       POLYBENCH_ARRAY(r));

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print_array(m, n, POLYBENCH_ARRAY(s), POLYBENCH_ARRAY(q)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(A);
  POLYBENCH_FREE_ARRAY(s);
  POLYBENCH_FREE_ARRAY(q);
  POLYBENCH_FREE_ARRAY(p);
  POLYBENCH_FREE_ARRAY(r);

  return 0;
}
