
#include <stdio.h>
#include <sys/time.h>
#include "rtclock.h"
#include <stdlib.h>
#define MAX_THREADS 256

/* Initialization temporal variables */
double t_start;

double tall_start;
/* récupération du nombre de threads, avant la section omp parallel.
 Avant la première exécution du programme, il faut renseigner la variable
 d'environnement : export OMP_NUM_THREADS=X, où X est le nombre de threads */
int _ThreadCount; 
double _time_threads[MAX_THREADS];





#include <math.h>
#define ceild(n,d)  (((n)<0) ? -((-(n))/(d)) : ((n)+(d)-1)/(d))
#define floord(n,d) (((n)<0) ? -((-(n)+(d)-1)/(d)) : (n)/(d))
#define max(x,y)    ((x) > (y)? (x) : (y))
#define min(x,y)    ((x) < (y)? (x) : (y))

#include <omp.h>
/**
 * This version is stamped on May 10, 2016
 *
 * Contact:
 *   Louis-Noel Pouchet <pouchet.ohio-state.edu>
 *   Tomofumi Yuki <tomofumi.yuki.fr>
 *
 * Web address: http://polybench.sourceforge.net
 */
/* syrk.c: this file is part of PolyBench/C */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include <polybench.h>

/* Include benchmark-specific header. */
#include "syrk.h"


/* Array initialization. */
static
void init_array(int n, int m,
		DATA_TYPE *alpha,
		DATA_TYPE *beta,
		DATA_TYPE POLYBENCH_2D(C,N,N,n,n),
		DATA_TYPE POLYBENCH_2D(A,N,M,n,m))
{
  int i, j;

  *alpha = 1.5;
  *beta = 1.2;
  for (i = 0; i < n; i++)
    for (j = 0; j < m; j++)
      A[i][j] = (DATA_TYPE) ((i*j+1)%n) / n;
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
      C[i][j] = (DATA_TYPE) ((i*j+2)%m) / m;
}


/* DCE code. Must scan the entire live-out data.
   Can be used also to check the correctness of the output. */
static
void print_array(int n,
		 DATA_TYPE POLYBENCH_2D(C,N,N,n,n))
{
  int i, j;

  POLYBENCH_DUMP_START;
  POLYBENCH_DUMP_BEGIN("C");
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++) {
	if ((i * n + j) % 20 == 0) fprintf (POLYBENCH_DUMP_TARGET, "\n");
	fprintf (POLYBENCH_DUMP_TARGET, DATA_PRINTF_MODIFIER, C[i][j]);
    }
  POLYBENCH_DUMP_END("C");
  POLYBENCH_DUMP_FINISH;
}


/* Main computational kernel. The whole function will be timed,
   including the call and return. */
static
void kernel_syrk(int n, int m,
		 DATA_TYPE alpha,
		 DATA_TYPE beta,
		 DATA_TYPE POLYBENCH_2D(C,N,N,n,n),
		 DATA_TYPE POLYBENCH_2D(A,N,M,n,m))
{
  int i, j, k;

//BLAS PARAMS
//TRANS = 'N'
//UPLO  = 'L'
// =>  Form  C := alpha*A*A**T + beta*C.
//A is NxM
//C is NxN
  int t1, t2, t3, t4, t5, t6, t7;
 int lb, ub, lbp, ubp, lb2, ub2;
 register int lbv, ubv;
if (_PB_N >= 1) {
  lbp=0;
  ubp=floord(_PB_N-1,64);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for schedule(dynamic) nowait private(lbv,ubv,t3,t4,t5,t6,t7)
  for (t2=lbp;t2<=ubp;t2++) {
    for (t3=0;t3<=min(floord(_PB_N-1,32),2*t2+1);t3++) {
      for (t4=max(64*t2,32*t3);t4<=min(_PB_N-1,64*t2+63);t4++) {
        lbv=32*t3;
        ubv=min(t4,32*t3+31);
#pragma GCC ivdep
        for (t5=lbv;t5<=ubv;t5++) {
          C[t4][t5] *= beta;;
        }
      }
    }
  }
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
  if (_PB_M >= 1) {
    lbp=0;
    ubp=floord(_PB_N-1,64);
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for schedule(dynamic) nowait private(lbv,ubv,t3,t4,t5,t6,t7)
    for (t2=lbp;t2<=ubp;t2++) {
      for (t3=0;t3<=min(floord(_PB_N-1,32),2*t2+1);t3++) {
        for (t4=0;t4<=_PB_M-1;t4++) {
          for (t5=max(64*t2,32*t3);t5<=min(_PB_N-1,64*t2+63);t5++) {
            for (t6=32*t3;t6<=min(t5,32*t3+31);t6++) {
              C[t5][t6] += alpha * A[t5][t4] * A[t6][t4];;
            }
          }
        }
      }
    }
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
  }
}

/* Affichage des temps d'exécution */
tall_start=rtclock()-tall_start; 
for(int i=0;i<_ThreadCount;i++){
printf("%0.6lf \n", _time_threads[i]);
}
 printf("##Execution time \n");

}


int main(int argc, char** argv)
{
_ThreadCount = atoi(getenv("OMP_NUM_THREADS"));
  for (int _i=0; _i<_ThreadCount; _i++) _time_threads[_i]=0.0; /*initialisation du tableau des mesures à 0 */
  /* temps d'exécution totale */
  tall_start=rtclock();

  /* Retrieve problem size. */
  int n = N;
  int m = M;

  /* Variable declaration/allocation. */
  DATA_TYPE alpha;
  DATA_TYPE beta;
  POLYBENCH_2D_ARRAY_DECL(C,DATA_TYPE,N,N,n,n);
  POLYBENCH_2D_ARRAY_DECL(A,DATA_TYPE,N,M,n,m);

  /* Initialize array(s). */
  init_array (n, m, &alpha, &beta, POLYBENCH_ARRAY(C), POLYBENCH_ARRAY(A));

  /* Start timer. */
  polybench_start_instruments;

  /* Run kernel. */
  kernel_syrk (n, m, alpha, beta, POLYBENCH_ARRAY(C), POLYBENCH_ARRAY(A));

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print_array(n, POLYBENCH_ARRAY(C)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(C);
  POLYBENCH_FREE_ARRAY(A);

  return 0;
}
