
#include <stdio.h>
#include <sys/time.h>
#include "rtclock.h"
#include <stdlib.h>
#define MAX_THREADS 256

/* Initialization temporal variables */
double t_start;

double tall_start;
/* récupération du nombre de threads, avant la section omp parallel.
 Avant la première exécution du programme, il faut renseigner la variable
 d'environnement : export OMP_NUM_THREADS=X, où X est le nombre de threads */
int _ThreadCount; 
double _time_threads[MAX_THREADS];





#include <math.h>
#define ceild(n, d) (((n) < 0) ? -((-(n)) / (d)) : ((n) + (d)-1) / (d))
#define floord(n, d) (((n) < 0) ? -((-(n) + (d)-1) / (d)) : (n) / (d))
#define max(x, y) ((x) > (y) ? (x) : (y))
#define min(x, y) ((x) < (y) ? (x) : (y))

#include "bench_pluto_a.c.trahrhe.0.h"
#include "bench_pluto_a.c.trahrhe.1.h"
#include "bench_pluto_a.c.trahrhe.2.h"
#include "bench_pluto_a.c.trahrhe.3.h"
#include "bench_pluto_a.c.trahrhe.4.h"
#include <omp.h>
/**
 * This version is stamped on May 10, 2016
 *
 * Contact:
 *   Louis-Noel Pouchet <pouchet.ohio-state.edu>
 *   Tomofumi Yuki <tomofumi.yuki.fr>
 *
 * Web address: http://polybench.sourceforge.net
 */
/* gesummv.c: this file is part of PolyBench/C */

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

/* Include polybench common header. */
#include <polybench.h>

/* Include benchmark-specific header. */
#include "gesummv.h"

/* Array initialization. */
static void init_array(int n, DATA_TYPE *alpha, DATA_TYPE *beta,
                       DATA_TYPE POLYBENCH_2D(A, N, N, n, n),
                       DATA_TYPE POLYBENCH_2D(B, N, N, n, n),
                       DATA_TYPE POLYBENCH_1D(x, N, n)) {
  int i, j;

  *alpha = 1.5;
  *beta = 1.2;
  for (i = 0; i < n; i++) {
    x[i] = (DATA_TYPE)(i % n) / n;
    for (j = 0; j < n; j++) {
      A[i][j] = (DATA_TYPE)((i * j + 1) % n) / n;
      B[i][j] = (DATA_TYPE)((i * j + 2) % n) / n;
    }
  }
}

/* DCE code. Must scan the entire live-out data.
   Can be used also to check the correctness of the output. */
static void print_array(int n, DATA_TYPE POLYBENCH_1D(y, N, n))

{
  int i;

  POLYBENCH_DUMP_START;
  POLYBENCH_DUMP_BEGIN("y");
  for (i = 0; i < n; i++) {
    if (i % 20 == 0)
      fprintf(POLYBENCH_DUMP_TARGET, "\n");
    fprintf(POLYBENCH_DUMP_TARGET, DATA_PRINTF_MODIFIER, y[i]);
  }
  POLYBENCH_DUMP_END("y");
  POLYBENCH_DUMP_FINISH;
}

/* Main computational kernel. The whole function will be timed,
   including the call and return. */
static void kernel_gesummv(int n, DATA_TYPE alpha, DATA_TYPE beta,
                           DATA_TYPE POLYBENCH_2D(A, N, N, n, n),
                           DATA_TYPE POLYBENCH_2D(B, N, N, n, n),
                           DATA_TYPE POLYBENCH_1D(tmp, N, n),
                           DATA_TYPE POLYBENCH_1D(x, N, n),
                           DATA_TYPE POLYBENCH_1D(y, N, n)) {
  int i, j;

  long int t1, t2, t3, t4, t5;
  int lb, ub, lbp, ubp, lb2, ub2;
  register int lbv, ubv;
  long int TILE_VOL_L0, t0_pcmax, alb0, aub0, aub0t;
  long int TILE_VOL_L1, t1_pcmax, alb1, aub1, aub1t;
  t0_pcmax = i1_Ehrhart(_PB_N);
  TILE_VOL_L0 = t0_pcmax / DIV0;
  aub0t = DIV0 - 1;
  ;
  lbp = 0;
  ubp = aub0t;
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait firstprivate(TILE_VOL_L0, aub0t, t0_pcmax) private(   \
    lbv, ubv, alb0, aub0, t3, t4, t5)
  for (t2 = lbp; t2 <= ubp; t2++) {
    alb0 = i1_trahrhe_i1(max((t2)*TILE_VOL_L0, 1), _PB_N);
    aub0 = i1_trahrhe_i1(min(((t2) + 1) * TILE_VOL_L0, t0_pcmax), _PB_N) - 1;
    if (t2 == aub0t) {
      aub0 = _PB_N - 1;
    }
    if (aub0 < alb0) {
      fprintf(stderr,
              "The tile volume of level 0 (%ld) seems too small, raise it and "
              "try again\n",
              TILE_VOL_L0);
      exit(1);
    };
    lbv = max(0, alb0);
    ubv = min(aub0, _PB_N - 1);
#pragma GCC ivdep
    for (t3 = lbv; t3 <= ubv; t3++) {
      y[t3] = SCALAR_VAL(0.0);
      ;
    }
  }
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
  t0_pcmax = i3_Ehrhart(_PB_N);
  TILE_VOL_L0 = t0_pcmax / DIV0;
  aub0t = DIV0 - 1;
  ;
  lbp = 0;
  ubp = aub0t;
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait firstprivate(TILE_VOL_L0, aub0t, t0_pcmax) private(   \
    lbv, ubv, alb0, aub0, alb1, aub1, TILE_VOL_L1, aub1t, t1_pcmax, t3, t4,    \
    t5)
  for (t2 = lbp; t2 <= ubp; t2++) {
    alb0 = i3_trahrhe_i3(max((t2)*TILE_VOL_L0, 1), _PB_N);
    aub0 = i3_trahrhe_i3(min(((t2) + 1) * TILE_VOL_L0, t0_pcmax), _PB_N) - 1;
    if (t2 == aub0t) {
      aub0 = _PB_N - 1;
    }
    if (aub0 < alb0) {
      fprintf(stderr,
              "The tile volume of level 0 (%ld) seems too small, raise it and "
              "try again\n",
              TILE_VOL_L0);
      exit(1);
    };
    t1_pcmax = j3_Ehrhart(_PB_N, alb0, aub0);
    TILE_VOL_L1 = t1_pcmax / DIV1;
    aub1t = DIV1 - 1;
    ;
    for (t3 = 0; t3 <= aub1t; t3++) {
      alb1 = j3_trahrhe_j3(max((t3)*TILE_VOL_L1, 1), _PB_N, alb0, aub0);
      aub1 = j3_trahrhe_j3(min(((t3) + 1) * TILE_VOL_L1, t1_pcmax), _PB_N, alb0,
                           aub0) -
             1;
      if (t3 == aub1t) {
        aub1 = _PB_N - 1;
      }
      if (aub1 < alb1) {
        fprintf(stderr,
                "The tile volume of level 1 (%ld) seems too small, raise it "
                "and try again\n",
                TILE_VOL_L1);
        exit(1);
      };
      for (t4 = max(0, alb0); t4 <= min(aub0, _PB_N - 1); t4++) {
        for (t5 = max(0, alb1); t5 <= min(aub1, _PB_N - 1); t5++) {
          y[t4] = B[t4][t5] * x[t5] + y[t4];
          ;
        }
      }
    }
  }
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
  t0_pcmax = i0_Ehrhart(_PB_N);
  TILE_VOL_L0 = t0_pcmax / DIV0;
  aub0t = DIV0 - 1;
  ;
  lbp = 0;
  ubp = aub0t;
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait firstprivate(TILE_VOL_L0, aub0t, t0_pcmax) private(   \
    lbv, ubv, alb0, aub0, t3, t4, t5)
  for (t2 = lbp; t2 <= ubp; t2++) {
    alb0 = i0_trahrhe_i0(max((t2)*TILE_VOL_L0, 1), _PB_N);
    aub0 = i0_trahrhe_i0(min(((t2) + 1) * TILE_VOL_L0, t0_pcmax), _PB_N) - 1;
    if (t2 == aub0t) {
      aub0 = _PB_N - 1;
    }
    if (aub0 < alb0) {
      fprintf(stderr,
              "The tile volume of level 0 (%ld) seems too small, raise it and "
              "try again\n",
              TILE_VOL_L0);
      exit(1);
    };
    lbv = max(0, alb0);
    ubv = min(aub0, _PB_N - 1);
#pragma GCC ivdep
    for (t3 = lbv; t3 <= ubv; t3++) {
      tmp[t3] = SCALAR_VAL(0.0);
      ;
    }
  }
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
  t0_pcmax = i2_Ehrhart(_PB_N);
  TILE_VOL_L0 = t0_pcmax / DIV0;
  aub0t = DIV0 - 1;
  ;
  lbp = 0;
  ubp = aub0t;
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait firstprivate(TILE_VOL_L0, aub0t, t0_pcmax) private(   \
    lbv, ubv, alb0, aub0, alb1, aub1, TILE_VOL_L1, aub1t, t1_pcmax, t3, t4,    \
    t5)
  for (t2 = lbp; t2 <= ubp; t2++) {
    alb0 = i2_trahrhe_i2(max((t2)*TILE_VOL_L0, 1), _PB_N);
    aub0 = i2_trahrhe_i2(min(((t2) + 1) * TILE_VOL_L0, t0_pcmax), _PB_N) - 1;
    if (t2 == aub0t) {
      aub0 = _PB_N - 1;
    }
    if (aub0 < alb0) {
      fprintf(stderr,
              "The tile volume of level 0 (%ld) seems too small, raise it and "
              "try again\n",
              TILE_VOL_L0);
      exit(1);
    };
    t1_pcmax = j2_Ehrhart(_PB_N, alb0, aub0);
    TILE_VOL_L1 = t1_pcmax / DIV1;
    aub1t = DIV1 - 1;
    ;
    for (t3 = 0; t3 <= aub1t; t3++) {
      alb1 = j2_trahrhe_j2(max((t3)*TILE_VOL_L1, 1), _PB_N, alb0, aub0);
      aub1 = j2_trahrhe_j2(min(((t3) + 1) * TILE_VOL_L1, t1_pcmax), _PB_N, alb0,
                           aub0) -
             1;
      if (t3 == aub1t) {
        aub1 = _PB_N - 1;
      }
      if (aub1 < alb1) {
        fprintf(stderr,
                "The tile volume of level 1 (%ld) seems too small, raise it "
                "and try again\n",
                TILE_VOL_L1);
        exit(1);
      };
      for (t4 = max(0, alb0); t4 <= min(aub0, _PB_N - 1); t4++) {
        for (t5 = max(0, alb1); t5 <= min(aub1, _PB_N - 1); t5++) {
          tmp[t4] = A[t4][t5] * x[t5] + tmp[t4];
          ;
        }
      }
    }
  }
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
  t0_pcmax = i4_Ehrhart(_PB_N);
  TILE_VOL_L0 = t0_pcmax / DIV0;
  aub0t = DIV0 - 1;
  ;
  lbp = 0;
  ubp = aub0t;
/* Premier appel à la fonction rtclock */
t_start = rtclock();
/*On ajoute la clause "shared(_time_threads) firstprivate(t_start)" et le nowait*/
#pragma omp parallel shared(_time_threads) firstprivate(t_start)
{

#pragma omp for nowait firstprivate(TILE_VOL_L0, aub0t, t0_pcmax) private(   \
    lbv, ubv, alb0, aub0, t3, t4, t5)
  for (t2 = lbp; t2 <= ubp; t2++) {
    alb0 = i4_trahrhe_i4(max((t2)*TILE_VOL_L0, 1), _PB_N);
    aub0 = i4_trahrhe_i4(min(((t2) + 1) * TILE_VOL_L0, t0_pcmax), _PB_N) - 1;
    if (t2 == aub0t) {
      aub0 = _PB_N - 1;
    }
    if (aub0 < alb0) {
      fprintf(stderr,
              "The tile volume of level 0 (%ld) seems too small, raise it and "
              "try again\n",
              TILE_VOL_L0);
      exit(1);
    };
    lbv = max(0, alb0);
    ubv = min(aub0, _PB_N - 1);
#pragma GCC ivdep
    for (t3 = lbv; t3 <= ubv; t3++) {
      y[t3] = alpha * tmp[t3] + beta * y[t3];
      ;
    }
  }
/*Collecte des temps de chaque thread */
_time_threads[omp_get_thread_num()] += rtclock() - t_start;
}
/* Affichage des temps d'exécution */
tall_start=rtclock()-tall_start; 
for(int i=0;i<_ThreadCount;i++){
printf("%0.6lf \n", _time_threads[i]);
}
 printf("##Execution time \n");

}

int main(int argc, char **argv) {
_ThreadCount = atoi(getenv("OMP_NUM_THREADS"));
  for (int _i=0; _i<_ThreadCount; _i++) _time_threads[_i]=0.0; /*initialisation du tableau des mesures à 0 */
  /* temps d'exécution totale */
  tall_start=rtclock();

  /* Retrieve problem size. */
  int n = N;

  /* Variable declaration/allocation. */
  DATA_TYPE alpha;
  DATA_TYPE beta;
  POLYBENCH_2D_ARRAY_DECL(A, DATA_TYPE, N, N, n, n);
  POLYBENCH_2D_ARRAY_DECL(B, DATA_TYPE, N, N, n, n);
  POLYBENCH_1D_ARRAY_DECL(tmp, DATA_TYPE, N, n);
  POLYBENCH_1D_ARRAY_DECL(x, DATA_TYPE, N, n);
  POLYBENCH_1D_ARRAY_DECL(y, DATA_TYPE, N, n);

  /* Initialize array(s). */
  init_array(n, &alpha, &beta, POLYBENCH_ARRAY(A), POLYBENCH_ARRAY(B),
             POLYBENCH_ARRAY(x));

  /* Start timer. */
  polybench_start_instruments;

  /* Run kernel. */
  kernel_gesummv(n, alpha, beta, POLYBENCH_ARRAY(A), POLYBENCH_ARRAY(B),
                 POLYBENCH_ARRAY(tmp), POLYBENCH_ARRAY(x), POLYBENCH_ARRAY(y));

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print_array(n, POLYBENCH_ARRAY(y)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(A);
  POLYBENCH_FREE_ARRAY(B);
  POLYBENCH_FREE_ARRAY(tmp);
  POLYBENCH_FREE_ARRAY(x);
  POLYBENCH_FREE_ARRAY(y);

  return 0;
}
